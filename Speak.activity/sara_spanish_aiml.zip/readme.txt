SARA - Sistema Artificial de Respuestas Autom�ticas (Artificial System of Automatic Responses)

Version 0.2 - March 15th 2006


AIML files created by Adam Codony aka XGargoyle


About Sara
----------

Sara is a spanish chatterbot created by Adam Codony, as a functional prototype for his graduation project in Multimedia by the Universitat Polit�cnica de Catalunya (UPC)

